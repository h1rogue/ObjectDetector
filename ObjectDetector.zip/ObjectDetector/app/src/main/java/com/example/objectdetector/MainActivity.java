package com.example.objectdetector;

import android.content.Intent;
import android.graphics.Bitmap;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.firebase.ml.vision.FirebaseVision;
import com.google.firebase.ml.vision.cloud.label.FirebaseVisionCloudLabelDetector;
import com.google.firebase.ml.vision.common.FirebaseVisionImage;
import com.google.firebase.ml.vision.label.FirebaseVisionLabelDetector;
import com.google.firebase.ml.vision.label.FirebaseVisionLabelDetectorOptions;


public class MainActivity extends AppCompatActivity {

    private ImageView imageView;
    private Bitmap bitmaImage;
    private Button snap, detect;
    private TextView textviewLabel;
    private FirebaseVisionImage image;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        imageView = findViewById(R.id.imageview);
        snap = findViewById(R.id.button);
        detect = findViewById(R.id.button2);
        textviewLabel = findViewById(R.id.textView);

        snap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dispatchTakePictureIntent();
            }
        });

        detect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                detectImage();
            }
        });
    }

    private void detectImage() {
     image  = FirebaseVisionImage.fromBitmap(bitmaImage);
        Log.d("working", "image vision is working");

        FirebaseVisionCloudLabelDetector detector=FirebaseVision
                .getInstance().getVisionCloudLabelDetector();

        Log.d("working", "image labeler is working");
    }

    static final int REQUEST_IMAGE_CAPTURE = 1;

    private void dispatchTakePictureIntent() {
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
            startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == RESULT_OK) {
            Bundle extras = data.getExtras();
            bitmaImage = (Bitmap) extras.get("data");
            imageView.setImageBitmap(bitmaImage);
        }
    }
}
